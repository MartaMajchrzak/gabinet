﻿namespace guitest
{
    partial class kartaZabieg
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Yellow;
            this.textBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(130, 83);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(385, 20);
            this.textBox1.TabIndex = 42;
            this.textBox1.Text = "Wybierz leczony ząb";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Location = new System.Drawing.Point(36, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(86, 20);
            this.textBox2.TabIndex = 43;
            this.textBox2.Text = "GÓRNA CZĘŚĆ";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Beige;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox3.Location = new System.Drawing.Point(36, 156);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(86, 20);
            this.textBox3.TabIndex = 44;
            this.textBox3.Text = "DOLNA CZĘŚĆ";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.textBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox4.Location = new System.Drawing.Point(475, 213);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(102, 20);
            this.textBox4.TabIndex = 45;
            this.textBox4.Text = "KOD CHOROBY";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.UseWaitCursor = true;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Próchnica",
            "Leczenie Kanałowe",
            "Korzeń",
            "Lakowanie",
            "Dziura",
            "Boli",
            "Badzo ",
            "Plomba"});
            this.checkedListBox1.Location = new System.Drawing.Point(467, 239);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(129, 169);
            this.checkedListBox1.TabIndex = 46;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox5.Location = new System.Drawing.Point(21, 323);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(101, 20);
            this.textBox5.TabIndex = 47;
            this.textBox5.Text = "Zażywane leki";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(127, 323);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(330, 20);
            this.textBox6.TabIndex = 48;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox7.Location = new System.Drawing.Point(21, 286);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(101, 20);
            this.textBox7.TabIndex = 49;
            this.textBox7.Text = "Podano leki";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(127, 286);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(330, 20);
            this.textBox8.TabIndex = 50;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(127, 225);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(330, 20);
            this.textBox9.TabIndex = 52;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox10.Location = new System.Drawing.Point(21, 225);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(101, 20);
            this.textBox10.TabIndex = 51;
            this.textBox10.Text = "Rozpoznanie";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(127, 251);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(330, 20);
            this.textBox11.TabIndex = 54;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox12.Location = new System.Drawing.Point(21, 251);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(101, 20);
            this.textBox12.TabIndex = 53;
            this.textBox12.Text = "Zabieg";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button1.Location = new System.Drawing.Point(436, 438);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 28);
            this.button1.TabIndex = 55;
            this.button1.Text = "Zapisz pacjenta";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.AliceBlue;
            this.textBox13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox13.HideSelection = false;
            this.textBox13.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textBox13.Location = new System.Drawing.Point(49, 15);
            this.textBox13.Name = "textBox13";
            this.textBox13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox13.Size = new System.Drawing.Size(41, 20);
            this.textBox13.TabIndex = 56;
            this.textBox13.Text = "Imię";
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox14.ForeColor = System.Drawing.Color.Black;
            this.textBox14.Location = new System.Drawing.Point(335, 15);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(53, 20);
            this.textBox14.TabIndex = 57;
            this.textBox14.Text = "Nazwisko";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(96, 15);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(154, 20);
            this.textBox15.TabIndex = 58;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(394, 15);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(154, 20);
            this.textBox16.TabIndex = 59;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(235, 41);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(249, 20);
            this.textBox17.TabIndex = 61;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox18.ForeColor = System.Drawing.Color.Black;
            this.textBox18.Location = new System.Drawing.Point(176, 41);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(148, 20);
            this.textBox18.TabIndex = 60;
            this.textBox18.Text = "PESEL";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button2.Location = new System.Drawing.Point(37, 438);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(171, 28);
            this.button2.TabIndex = 62;
            this.button2.Text = "Wróć do zapisu";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(127, 349);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(330, 20);
            this.textBox19.TabIndex = 64;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox20.Location = new System.Drawing.Point(21, 349);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(101, 20);
            this.textBox20.TabIndex = 63;
            this.textBox20.Text = "Zalecenia";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button3.Location = new System.Drawing.Point(130, 118);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(23, 22);
            this.button3.TabIndex = 65;
            this.button3.Text = "8";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button4.Location = new System.Drawing.Point(304, 118);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(23, 22);
            this.button4.TabIndex = 66;
            this.button4.Text = "2";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button5.Location = new System.Drawing.Point(275, 118);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(23, 22);
            this.button5.TabIndex = 67;
            this.button5.Text = "3";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button6
            // 
            this.button6.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button6.Location = new System.Drawing.Point(246, 118);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(23, 22);
            this.button6.TabIndex = 68;
            this.button6.Text = "4";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button7
            // 
            this.button7.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button7.Location = new System.Drawing.Point(217, 118);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(23, 22);
            this.button7.TabIndex = 69;
            this.button7.Text = "5";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button8
            // 
            this.button8.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button8.Location = new System.Drawing.Point(188, 118);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(23, 22);
            this.button8.TabIndex = 70;
            this.button8.Text = "6";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button9
            // 
            this.button9.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button9.Location = new System.Drawing.Point(159, 118);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(23, 22);
            this.button9.TabIndex = 71;
            this.button9.Text = "7";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button16
            // 
            this.button16.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button16.Location = new System.Drawing.Point(333, 118);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(23, 22);
            this.button16.TabIndex = 72;
            this.button16.Text = "1";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button17.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button17.Location = new System.Drawing.Point(333, 154);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(23, 22);
            this.button17.TabIndex = 86;
            this.button17.Text = "1";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button18.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button18.Location = new System.Drawing.Point(159, 154);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(23, 22);
            this.button18.TabIndex = 85;
            this.button18.Text = "7";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button19.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button19.Location = new System.Drawing.Point(188, 154);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(23, 22);
            this.button19.TabIndex = 84;
            this.button19.Text = "6";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button20.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button20.Location = new System.Drawing.Point(217, 154);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(23, 22);
            this.button20.TabIndex = 83;
            this.button20.Text = "5";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button21.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button21.Location = new System.Drawing.Point(246, 154);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(23, 22);
            this.button21.TabIndex = 82;
            this.button21.Text = "4";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button22.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button22.Location = new System.Drawing.Point(275, 154);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(23, 22);
            this.button22.TabIndex = 81;
            this.button22.Text = "3";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button23.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button23.Location = new System.Drawing.Point(304, 154);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(23, 22);
            this.button23.TabIndex = 80;
            this.button23.Text = "2";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button24.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button24.Location = new System.Drawing.Point(130, 154);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(23, 22);
            this.button24.TabIndex = 79;
            this.button24.Text = "8";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button10
            // 
            this.button10.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button10.Location = new System.Drawing.Point(380, 120);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(23, 22);
            this.button10.TabIndex = 87;
            this.button10.Text = "1";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button11
            // 
            this.button11.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button11.Location = new System.Drawing.Point(409, 120);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(23, 22);
            this.button11.TabIndex = 88;
            this.button11.Text = "2";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button12
            // 
            this.button12.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button12.Location = new System.Drawing.Point(438, 120);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(23, 22);
            this.button12.TabIndex = 89;
            this.button12.Text = "3";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button13
            // 
            this.button13.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button13.Location = new System.Drawing.Point(467, 120);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(23, 22);
            this.button13.TabIndex = 90;
            this.button13.Text = "4";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button14
            // 
            this.button14.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button14.Location = new System.Drawing.Point(496, 120);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(23, 22);
            this.button14.TabIndex = 91;
            this.button14.Text = "5";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button15
            // 
            this.button15.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button15.Location = new System.Drawing.Point(525, 120);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(23, 22);
            this.button15.TabIndex = 92;
            this.button15.Text = "6";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button25
            // 
            this.button25.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button25.Location = new System.Drawing.Point(554, 120);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(23, 22);
            this.button25.TabIndex = 93;
            this.button25.Text = "7";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button26
            // 
            this.button26.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button26.Location = new System.Drawing.Point(584, 120);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(23, 22);
            this.button26.TabIndex = 94;
            this.button26.Text = "8";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button27.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button27.Location = new System.Drawing.Point(580, 154);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(23, 22);
            this.button27.TabIndex = 102;
            this.button27.Text = "8";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button28.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button28.Location = new System.Drawing.Point(550, 154);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(23, 22);
            this.button28.TabIndex = 101;
            this.button28.Text = "7";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button29.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button29.Location = new System.Drawing.Point(521, 154);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(23, 22);
            this.button29.TabIndex = 100;
            this.button29.Text = "6";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button30.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button30.Location = new System.Drawing.Point(492, 154);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(23, 22);
            this.button30.TabIndex = 99;
            this.button30.Text = "5";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button31.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button31.Location = new System.Drawing.Point(463, 154);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(23, 22);
            this.button31.TabIndex = 98;
            this.button31.Text = "4";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button32.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button32.Location = new System.Drawing.Point(434, 154);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(23, 22);
            this.button32.TabIndex = 97;
            this.button32.Text = "3";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button33.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button33.Location = new System.Drawing.Point(405, 154);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(23, 22);
            this.button33.TabIndex = 96;
            this.button33.Text = "2";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.MediumTurquoise;
            this.button34.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button34.Location = new System.Drawing.Point(376, 154);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(23, 22);
            this.button34.TabIndex = 95;
            this.button34.Text = "1";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.dodawanie_zab);
            // 
            // kartaZabieg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(632, 496);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Name = "kartaZabieg";
            this.Text = "Zabieg";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
    }
}

